export default {
  appDirectory: 'app',
  buildDirectory: 'dist',
  ssr: true,
};

/** @typedef {import('@react-router/dev/config').Config} Config */
